/*
  mtr.h - Library for PWM motor control
*/

#include "Arduino.h"
#include "mtr.h"

mtr::mtr(int EN, int IN1, int IN2)
{
  pinMode(EN, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  _EN = EN;
  _IN1 = IN1;
  _IN2 = IN2;
}

void mtr::motorSpin(bool mDirection, int mSpeed) {
  //analogWrite(_EN, mSpeed); // PWM on enable pin
  if (mDirection) { // forward
    digitalWrite(_IN1, HIGH);
    digitalWrite(_IN2, LOW);
  } else { // backward
    digitalWrite(_IN1, LOW);
    digitalWrite(_IN2, HIGH);
  }
  digitalWrite(_EN, HIGH); // Motor Enable
  delay(mSpeed);
  digitalWrite(_EN,LOW); // Mtor Disable
}

void mtr::motorStop() {
  digitalWrite(_EN, LOW); // stop motor
}

