/*
  mtr.h - Library for PWM motor control
*/

#ifndef mtr_h
#define mtr_h

#include "Arduino.h"

class mtr
{
  public:
    mtr(int EN, int IN1, int IN2);
    void motorSpin(bool mDirection, int mSpeed);
    void motorStop();
    int _EN;
    int _IN1;
    int _IN2;
};

#endif
