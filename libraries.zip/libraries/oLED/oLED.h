/*
  oLED - Library for displaying and navigation
			   of a menu on an oLED screen
*/

#ifndef oLED_h
#define oLED_h

#include "Arduino.h"
#include "U8glib.h" //graphics library for oLED screen

class oLED
{
  public:
    oLED(bool rotate);
	void tuner(float freq, float freqDist);
    void noteSelection(char letter, int octave, bool sharp, int selectNum, bool showHide);
	void startup();
	void drawMenu(char str1[], char str2[], char str3[], char str4[]);
	bool _rotate;
	int displayWidth = 128;
	int displayHeight = 64;
};

#endif