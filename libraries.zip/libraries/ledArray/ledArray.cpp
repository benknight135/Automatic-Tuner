/*
  ledArray.h - Library for control of Led array
*/

#include "Arduino.h"
#include "ledArray.h"

ledArray::ledArray(int ledRedL,int ledYellowL,int ledGreen,int ledYellowR,int ledRedR)
{
  pinMode(ledRedL, OUTPUT);
  pinMode(ledYellowL, OUTPUT);
  pinMode(ledGreen, OUTPUT);
  pinMode(ledYellowR, OUTPUT);
  pinMode(ledRedR, OUTPUT);
  _ledRedL = ledRedL;
  _ledYellowL = ledYellowL;
  _ledGreen = ledGreen;
  _ledRedR = ledRedR;
  _ledYellowR = ledYellowR;
}

void ledArray::startup(){
	digitalWrite(_ledRedL, HIGH);
    delay(200);
    digitalWrite(_ledYellowL, HIGH);
    delay(200);
    digitalWrite(_ledGreen, HIGH);
    delay(200);
    digitalWrite(_ledYellowR, HIGH);
    delay(200);
    digitalWrite(_ledRedR, HIGH);
    delay(1000);
}

void ledArray::tuner(double freqDist, double inTuneRange) {
  double maxDistTol = 100;
  double distIncrement = 0.4; // distance from minimum tolerance
  if (freqDist == 0){
    this->allOff();
  } else if ((freqDist >= -inTuneRange) && (freqDist <= inTuneRange)) {
    this->onlyOne(3);
  } else if ((freqDist >= inTuneRange) && (freqDist <= inTuneRange + distIncrement)) {
    this->onlyOne(2);
  } else if ((freqDist >= inTuneRange + distIncrement) && (freqDist <= maxDistTol)) {
    this->onlyOne(1);
  } else if ((freqDist <= -inTuneRange) && (freqDist >= -inTuneRange - distIncrement)) {
    this->onlyOne(4);
  } else if ((freqDist <= -inTuneRange - distIncrement) && (freqDist >= -maxDistTol)) {
    this->onlyOne(5);
  }
}

void ledArray::allOff(){
	digitalWrite(_ledRedL, LOW);
	digitalWrite(_ledYellowL, LOW);
    digitalWrite(_ledGreen, LOW);
    digitalWrite(_ledYellowR, LOW);
    digitalWrite(_ledRedR, LOW);
}

void ledArray::onlyOne(int ledNum){
	switch (ledNum) {
		case 1: // red left
			digitalWrite(_ledRedR, HIGH);
			digitalWrite(_ledYellowR, LOW);
			digitalWrite(_ledGreen, LOW);
			digitalWrite(_ledYellowL, LOW);
			digitalWrite(_ledRedL, LOW);
			break;
		case 2: // yellow left
			digitalWrite(_ledRedR, LOW);
			digitalWrite(_ledYellowR, HIGH);
			digitalWrite(_ledGreen, LOW);
			digitalWrite(_ledYellowL, LOW);
			digitalWrite(_ledRedL, LOW);
			break;
		case 3: // green
			digitalWrite(_ledRedR, LOW);
			digitalWrite(_ledYellowR, LOW);
			digitalWrite(_ledGreen, HIGH);
			digitalWrite(_ledYellowL, LOW);
			digitalWrite(_ledRedL, LOW);
			break;
		case 4: // yellow right
			digitalWrite(_ledRedR, LOW);
			digitalWrite(_ledYellowR, LOW);
			digitalWrite(_ledGreen, LOW);
			digitalWrite(_ledYellowL, HIGH);
			digitalWrite(_ledRedL, LOW);
			break;
		case 5: // red right
			digitalWrite(_ledRedR, LOW);
			digitalWrite(_ledYellowL, LOW);
			digitalWrite(_ledGreen, LOW);
			digitalWrite(_ledYellowL, LOW);
			digitalWrite(_ledRedL, HIGH);
			break;
		default: // all off
			digitalWrite(_ledRedR, LOW);
			digitalWrite(_ledYellowR, LOW);
			digitalWrite(_ledGreen, LOW);
			digitalWrite(_ledYellowL, LOW);
			digitalWrite(_ledRedL, LOW);
			break;
	}
}

