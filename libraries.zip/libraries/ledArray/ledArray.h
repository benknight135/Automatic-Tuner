/*
  ledArray.h - Library for control of Led array
*/

#ifndef ledArray_h
#define ledArray_h

#include "Arduino.h"

class ledArray
{
  public:
    ledArray(int ledRedL,int ledYellowL,int ledGreen,int ledYellowR,int ledRedR);
    void startup();
	void tuner(double freqDist, double inTuneRange);
	void allOff();
	void onlyOne(int ledNum);
    int _ledRedL;
    int _ledYellowL;
    int _ledGreen;
	int _ledRedR;
    int _ledYellowR;
};

#endif
